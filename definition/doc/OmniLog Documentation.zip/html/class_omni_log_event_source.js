var class_omni_log_event_source =
[
    [ "$campaignId", "class_omni_log_event_source.html#ab8ce8cf26017fe7fa8ffe72613637d61", null ],
    [ "$component", "class_omni_log_event_source.html#a52a372047d9904ee90c99eaa2cd250d5", null ],
    [ "$creativeId", "class_omni_log_event_source.html#a7618ac010997638cc5fea12ee5222d38", null ],
    [ "$elementLabel", "class_omni_log_event_source.html#a6d1f429b2b4d668d46edc1c733e5a08a", null ],
    [ "$elementType", "class_omni_log_event_source.html#a208f532c8ee8092fd2f572071340646d", null ],
    [ "$entityId", "class_omni_log_event_source.html#afb30c1a7c33d36aa3a9518ad17217c31", null ],
    [ "$entityType", "class_omni_log_event_source.html#a67ae53afb74c2ecf00a10ab7adc33c1d", null ],
    [ "$experienceId", "class_omni_log_event_source.html#ad71b196a3c178500cc0e89cbcf84582c", null ],
    [ "$flowId", "class_omni_log_event_source.html#a9c96a29ebafaf17327ff52b4c694a467", null ],
    [ "$inputType", "class_omni_log_event_source.html#ab97af695ed984d74398461384c389868", null ],
    [ "$placement", "class_omni_log_event_source.html#abeec72cd2523c387484156134bb7c143", null ],
    [ "$positionId", "class_omni_log_event_source.html#a56e96a669b223bbd5ff69d4048022e1d", null ],
    [ "$section", "class_omni_log_event_source.html#aecc164f73478ddab97403e1e6a0aa2aa", null ]
];