var annotated_dup =
[
    [ "OmniLog", "class_omni_log.html", "class_omni_log" ],
    [ "OmniLogEventSource", "class_omni_log_event_source.html", "class_omni_log_event_source" ],
    [ "RoutingDescriptor", "class_routing_descriptor.html", null ]
];