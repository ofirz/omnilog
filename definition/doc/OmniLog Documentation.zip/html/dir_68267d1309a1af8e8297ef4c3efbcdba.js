var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "OmniLog.php", "_omni_log_8php.html", [
      [ "OmniLog", "class_omni_log.html", "class_omni_log" ]
    ] ],
    [ "OmniLogEventSource.php", "_omni_log_event_source_8php.html", [
      [ "OmniLogEventSource", "class_omni_log_event_source.html", "class_omni_log_event_source" ]
    ] ],
    [ "RoutingDescriptor.php", "_routing_descriptor_8php.html", [
      [ "RoutingDescriptor", "class_routing_descriptor.html", null ]
    ] ]
];