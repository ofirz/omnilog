var searchData=
[
  ['omnilog_45',['OmniLog',['../class_omni_log.html',1,'']]],
  ['omnilogeventsource_46',['OmniLogEventSource',['../class_omni_log_event_source.html',1,'']]]
];
