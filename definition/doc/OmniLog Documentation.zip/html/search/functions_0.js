var searchData=
[
  ['abregistered_51',['abRegistered',['../class_omni_log.html#a45b560be0d31120aea3a8a529e96d3bf',1,'OmniLog']]],
  ['appstarted_52',['appStarted',['../class_omni_log.html#a9c368279d518e4c04916994a4e0ad1a0',1,'OmniLog']]],
  ['appstopped_53',['appStopped',['../class_omni_log.html#a1178cf0d7401212030b7ad4a8ca19816',1,'OmniLog']]]
];
