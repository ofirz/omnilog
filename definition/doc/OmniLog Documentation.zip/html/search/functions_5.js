var searchData=
[
  ['sendevent_63',['sendEvent',['../class_omni_log.html#a8c4ecba9e3afacc76a0095b9311a95f5',1,'OmniLog']]],
  ['sendflowevent_64',['sendFlowEvent',['../class_omni_log.html#aa937144c9304e4503c53bc0113723c56',1,'OmniLog']]],
  ['sendinteractionevent_65',['sendInteractionEvent',['../class_omni_log.html#ae0f4bc5b80f16e93120399d0d752b4e6',1,'OmniLog']]],
  ['sendoutcomeevent_66',['sendOutcomeEvent',['../class_omni_log.html#a1921a5ba187da839faf9807c260d4f97',1,'OmniLog']]],
  ['sendplatformevent_67',['sendPlatformEvent',['../class_omni_log.html#abd35db82f556105dd01bd4411d682639',1,'OmniLog']]],
  ['sessionended_68',['sessionEnded',['../class_omni_log.html#a9bbedec7be518e799887b44067422f04',1,'OmniLog']]],
  ['sessionstarted_69',['sessionStarted',['../class_omni_log.html#acb95b4e26fd3b893741530d5698ca302',1,'OmniLog']]]
];
