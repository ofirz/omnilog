var searchData=
[
  ['routingdescriptor_2ephp_50',['RoutingDescriptor.php',['../_routing_descriptor_8php.html',1,'']]]
];
